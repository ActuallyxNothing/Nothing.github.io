import gameData from "../games.json";

export const games = gameData as Game[];
